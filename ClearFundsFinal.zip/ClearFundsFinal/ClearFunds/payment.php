<?php
session_start();

// ✅ Ensure donor is logged in
if (!isset($_SESSION['donor_id'])) {
    header("Location: donor_login.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root"; 
$password = "";     
$dbname = "ngo_donation";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$popupScript = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ngoName = trim($_POST['ngoName']);
    $amount = (float) $_POST['amount'];
    $fullName = trim($_POST['fullName']);
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $paymentMethod = $_POST['payment'] ?? null;

    $user_id = $_SESSION['donor_id'];

    // ✅ Get NGO id from ngo_name
    $ngo_id = null;
    $ngoQuery = $conn->prepare("SELECT id FROM ngos WHERE ngo_name = ?");
    if ($ngoQuery) {
        $ngoQuery->bind_param("s", $ngoName);
        $ngoQuery->execute();
        $ngoResult = $ngoQuery->get_result();
        if ($ngoResult->num_rows > 0) {
            $ngoRow = $ngoResult->fetch_assoc();
            $ngo_id = $ngoRow['id'];
        }
        $ngoQuery->close();
    }

    if ($amount >= 10 && $user_id && $ngo_id && $paymentMethod) {
        $sql = "INSERT INTO transactions 
                (user_id, ngo_id, donor_name, donor_email, donor_mobile, amount, payment_method, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'success')";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("iisssis", 
                $user_id, $ngo_id, $fullName, $email, $mobile, $amount, $paymentMethod);

            if ($stmt->execute()) {
                // ✅ Success popup + redirect
                $popupScript = "<script>
                    alert('✅ Payment Successful! Thank you $fullName. Donation ₹$amount recorded.');
                    window.location.href='UserInterface.php';
                </script>";
            } else {
                $popupScript = "<script>alert('Error saving transaction: ".$stmt->error."');</script>";
            }
        } else {
            $popupScript = "<script>alert('SQL Prepare failed: ".$conn->error."');</script>";
        }
    } else {
        $popupScript = "<script>alert('❌ Please fill all fields, select payment method, and donate at least ₹10');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donate - ClearFunds</title>
  <style>
    body { background:#e0f7fa; display:flex; justify-content:center; align-items:center; min-height:100vh; font-family:Arial; }
    .container { background:#fff; padding:30px; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.1); width:100%; max-width:450px; }
    h1 { text-align:center; margin-bottom:20px; color:#333; }
    label { font-weight:bold; margin-top:10px; display:block; }
    input[type="text"], input[type="number"], input[type="email"] { width:100%; padding:10px; border:1px solid #ccc; border-radius:8px; margin-bottom:15px; }
    .note { font-size:12px; color:#666; margin-top:-10px; margin-bottom:15px; }
    .payment-methods { margin-bottom:15px; }
    .payment-methods label { font-weight:normal; display:block; margin:5px 0; }
    .btn { width:100%; padding:12px; background:#00c853; color:white; font-weight:bold; border:none; border-radius:8px; cursor:pointer; margin-top:10px; }
    .btn:hover { background:#009e44; }
    .back-link { display:block; text-align:center; margin-top:15px; color:#00bcd4; text-decoration:none; }
    .back-link:hover { text-decoration:underline; }
    .qr-box { display:none; text-align:center; margin-top:10px; }
    .qr-box img { width:180px; height:180px; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Complete Payment</h1>

    <form method="POST" action="">
      <input type="hidden" name="ngoName" value="<?php echo isset($_GET['ngo']) ? htmlspecialchars($_GET['ngo']) : 'NGO Name'; ?>">

      <label for="amount">Donation Amount (₹)</label>
      <input type="number" name="amount" required>
      <p class="note">Minimum donation ₹10</p>

      <label for="fullName">Full Name</label>
      <input type="text" name="fullName" required>

      <label for="email">Email</label>
      <input type="email" name="email" required>

      <label for="mobile">Mobile Number</label>
      <input type="text" name="mobile" required>

      <div class="payment-methods">
        <label><input type="radio" name="payment" value="upi"> UPI</label>
        <label><input type="radio" name="payment" value="card"> Card</label>
        <label><input type="radio" name="payment" value="netbanking"> Net Banking</label>
        <label><input type="radio" name="payment" value="qr" onclick="toggleQR(true)"> UPI QR Code</label>
      </div>

      <div class="qr-box" id="qrBox">
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=ngo@upi">
        <p>Scan this QR code using any UPI app</p>
      </div>

      <button type="submit" class="btn">Complete Transaction</button>
    </form>
    <a href="UserInterface.php" class="back-link">← Back to NGOs</a>
  </div>

  <?php echo $popupScript; ?>

  <script>
    function toggleQR(show) {
      document.getElementById("qrBox").style.display = show ? 'block' : 'none';
    }
  </script>
</body>
</html>
