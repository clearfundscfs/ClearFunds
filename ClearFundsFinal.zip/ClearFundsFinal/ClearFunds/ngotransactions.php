<?php
session_start();
include("db_connect.php");

$ngo_id = $_SESSION['ngo_id'] ?? 0;
$sql = "SELECT t.id, u.full_name AS donor_name, t.amount, t.payment_method, t.status, t.transaction_date
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        WHERE t.ngo_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $ngo_id);
$stmt->execute();
$result = $stmt->get_result();
?>
