<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['email'] = $row['email'];
            header("Location: UserInterface.php");
            exit();
        } else {
            $error = "❌ Invalid password!";
        }
    } else {
        $error = "❌ User not found!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <style>
    /* Reset and base styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    body {
      background-color: #f3f4f6; /* gray-100 */
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    /* Card container */
    .card {
      background: #fff;
      padding: 2rem;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      width: 100%;
      max-width: 400px;
      animation: fadeUp 0.6s ease forwards;
    }

    /* Title */
    .card h1 {
      text-align: center;
      font-size: 1.8rem;
      font-weight: bold;
      color: #1f2937; /* gray-800 */
      margin-bottom: 1.5rem;
    }

    /* Error */
    .error {
      color: red;
      font-size: 0.9rem;
      text-align: center;
      margin-bottom: 10px;
    }

    /* Form */
    form {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    label {
      font-size: 0.9rem;
      color: #4b5563; /* gray-600 */
      margin-bottom: 0.2rem;
      display: block;
    }

    input {
      width: 100%;
      padding: 0.7rem;
      border: 1px solid #d1d5db; /* gray-300 */
      border-radius: 10px;
      font-size: 1rem;
      outline: none;
      transition: 0.2s;
    }

    input:focus {
      border-color: #3b82f6; /* blue-500 */
      box-shadow: 0 0 0 3px rgba(59,130,246,0.3);
    }

    button {
      background: #2563eb; /* blue-600 */
      color: white;
      padding: 0.8rem;
      border: none;
      border-radius: 12px;
      font-size: 1rem;
      cursor: pointer;
      transition: 0.2s;
    }

    button:hover {
      background: #1e40af; /* darker blue */
    }

    /* Footer */
    .footer-text {
      text-align: center;
      margin-top: 1rem;
      font-size: 0.9rem;
      color: #6b7280; /* gray-500 */
    }

    .footer-text a {
      color: #2563eb;
      text-decoration: none;
    }

    .footer-text a:hover {
      text-decoration: underline;
    }

    /* Animation */
    @keyframes fadeUp {
      from {
        opacity: 0;
        transform: translateY(50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>
<body>

  <div class="card">
    <h1>Login</h1>

    <?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="POST">
      <div>
        <label for="email">User ID</label>
        <input type="email" id="email" name="email" placeholder="Enter your user ID" required>
      </div>

      <div>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>
      </div>

      <button type="submit">Log in</button>
    </form>

    <p class="footer-text">
      Don’t have an account? <a href="https://docs.google.com/forms/d/e/1FAIpQLSfE91VT57QtAs4qdNdgmbjcpZd-4z9toD3xrNHeckkilIVyTQ/viewform?usp=header">Register</a>
    </p>
  </div>

</body>
</html>
