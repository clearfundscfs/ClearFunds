<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>About Us</title>
  <style>
    body { font-family:Arial; background:#f4f4f4; }
    .container { width:70%; margin:50px auto; background:white; padding:30px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.1); }
    h1 { color:#2c3e50; }
    p { font-size:16px; line-height:1.6; }
    a { display:inline-block; margin-top:20px; padding:10px 20px; background:#28a745; color:white; border-radius:5px; text-decoration:none; }
    a:hover { background:#218838; }
  </style>
</head>
<body>
  <div class="container">
    <h1>About Us</h1>
    <p>
      Welcome to <b>ClearFunds</b> – a transparent and secure donation platform.  
      Our mission is to connect donors with NGOs while ensuring complete accountability of funds.  
      Donors can track their contributions and NGOs can showcase their impact.
    </p>
    <a href="option2.php">⬅ Back</a>
  </div>
</body>
</html>
