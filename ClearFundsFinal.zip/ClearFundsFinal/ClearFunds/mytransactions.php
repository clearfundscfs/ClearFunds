<?php
session_start();
include("db.php"); // contains DB connection

// Ensure donor is logged in
if (!isset($_SESSION['donor_id'])) {
    header("Location: donor_login.php");
    exit();
}

$donor_id = $_SESSION['donor_id'];

$sql = "SELECT t.id, n.ngo_name, t.amount, t.payment_method, t.status, t.date
        FROM transactions t
        JOIN ngos n ON t.ngo_id = n.id
        WHERE t.user_id = ?
        ORDER BY t.date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $donor_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Donations</title>
  <style>
    body { font-family: Arial, sans-serif; background:#f4f4f4; }
    .container {
      width: 80%; margin: 40px auto;
      background: #fff; padding: 20px;
      border-radius: 10px; box-shadow: 0 0 8px rgba(0,0,0,0.1);
    }
    h2 { text-align:center; margin-bottom:20px; }
    table { width: 100%; border-collapse: collapse; }
    table, th, td { border: 1px solid #ccc; }
    th, td {
      padding: 12px; text-align: center;
    }
    th { background: #28a745; color: white; }
    tr:nth-child(even) { background:#f9f9f9; }
    .no-data { text-align:center; padding:20px; color:#555; }
  </style>
</head>
<body>
  <div class="container">
    <h2>My Donations</h2>
    <?php if ($result->num_rows > 0): ?>
      <table>
        <tr>
          <th>ID</th>
          <th>NGO</th>
          <th>Amount (₹)</th>
          <th>Payment Method</th>
          <th>Status</th>
          <th>Date</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['ngo_name']); ?></td>
            <td><?php echo $row['amount']; ?></td>
            <td><?php echo ucfirst($row['payment_method']); ?></td>
            <td><?php echo ucfirst($row['status']); ?></td>
            <td><?php echo $row['date']; ?></td>
          </tr>
        <?php endwhile; ?>
      </table>
    <?php else: ?>
      <p class="no-data">You have not made any donations yet.</p>
    <?php endif; ?>
  </div>
</body>
</html>
