<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $password);

    if ($stmt->execute()) {
        $msg = "Registration successful! <a href='login.php'>Login</a>";
    } else {
        $msg = "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <style>
    body { background:#f4f4f4; font-family:sans-serif; }
    .reg-box { width:350px; margin:100px auto; padding:30px; background:white; border-radius:10px; box-shadow:0 0 8px rgba(0,0,0,0.1); }
    input { width:100%; margin:10px 0; padding:10px; border:1px solid #ccc; border-radius:5px; }
    button { width:100%; padding:10px; background:#007bff; color:white; border:none; border-radius:5px; cursor:pointer; }
    button:hover { background:#0056b3; }
    .msg { margin:10px 0; }
  </style>
</head>
<body>
  <div class="reg-box">
    <h2>Sign Up</h2>
    <?php if(isset($msg)) echo "<p class='msg'>$msg</p>"; ?>
    <form method="POST">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Sign Up</button>
    </form>
  </div>
</body>
</html>
