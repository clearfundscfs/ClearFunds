<?php
// Database Connection (db.php)

$host = "localhost";
$user = "root";   // default XAMPP user
$pass = "";       // default password
$db   = "ngo_donation";

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("❌ Database Connection failed: " . $conn->connect_error);
}

// Optional: set charset to avoid encoding issues
$conn->set_charset("utf8mb4");
?>
