<?php
// Start session
session_start();

// (Optional) Database connection
$servername = "localhost";
$username = "root"; // default for XAMPP
$password = "";
$dbname = "ngo_donation";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Later you can fetch NGOs from DB; for now we use static cards.
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NGO Listing Final UI</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
    body { color: #333; display: flex; flex-direction: column; min-height: 100vh; overflow-y: auto; }

    /* Background Slider */
    .background-slider { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -2; overflow: hidden; }
    .background-slider img { position: absolute; width: 100%; height: 100%; object-fit: cover; opacity: 0; animation: fade 9s infinite; }
    .background-slider img:nth-child(1) { animation-delay: 0s; }
    .background-slider img:nth-child(2) { animation-delay: 3s; }
    .background-slider img:nth-child(3) { animation-delay: 6s; }
    @keyframes fade { 0%, 100% { opacity: 0; } 10%, 30% { opacity: 1; } 40% { opacity: 0; } }

    .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255, 255, 255, 0.4); z-index: -1; }

    /* Header */
    header { background: #00bcd4; color: white; padding: 20px; display: flex; align-items: center; justify-content: space-between; gap: 15px; }
    header h1 { font-size: 28px; font-weight: bold; }
    header p { font-size: 14px; color: #dff6fa; }
    .transactions-btn { padding: 10px 18px; background: white; color: #00bcd4; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold; transition: background 0.3s, color 0.3s; }
    .transactions-btn:hover { background: #e0f7fa; color: #0097a7; }

    /* Search */
    .search-container { display: flex; justify-content: center; align-items: center; padding: 15px; background: #fff; border-bottom: 1px solid #ddd; gap: 10px; }
    .search-bar { flex: 1; max-width: 600px; padding: 10px 15px; border-radius: 6px; border: 1px solid #ccc; outline: none; font-size: 14px; }

    /* NGO List */
    .ngo-list { display: flex; flex-direction: column; gap: 20px; padding: 30px 20px; width: 80%; max-width: 1000px; margin: 0 auto; flex-grow: 1; }
    .ngo-card { background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08); display: flex; flex-direction: column; transition: transform 0.2s ease-in-out; }
    .ngo-card:hover { transform: scale(1.01); }
    .ngo-card h3 { color: #00bcd4; margin-bottom: 6px; }
    .ngo-card p { color: #555; margin-bottom: 12px; }
    .view-btn { align-self: flex-start; padding: 8px 16px; background: #00bcd4; color: white; border: none; border-radius: 6px; cursor: pointer; }
    .view-btn:hover { background: #0097a7; }

    /* Modal */
    .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); justify-content: center; align-items: center; z-index: 10000; }
    .modal-content { background: white; padding: 25px; width: 90%; max-width: 700px; border-radius: 15px; text-align: center; position: relative; border: 3px solid; border-image: linear-gradient(45deg, #00bcd4, #a1ffce) 1; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2); animation: zoomIn 0.3s ease; }
    @keyframes zoomIn { 0% { transform: scale(0.7); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
    .close-btn { position: absolute; top: 12px; right: 15px; font-size: 26px; cursor: pointer; color: #444; }
    .donate-btn { background: #00e676; color: white; padding: 12px 24px; border: none; border-radius: 8px; cursor: pointer; margin-top: 15px; font-size: 16px; font-weight: bold; box-shadow: 0 0 12px rgba(0, 230, 118, 0.7); transition: all 0.3s ease; }
    .donate-btn:hover { background: #00c853; transform: scale(1.05); box-shadow: 0 0 18px rgba(0, 230, 118, 0.9); }

    footer { text-align: center; padding: 15px; background: #fff; border-top: 1px solid #ddd; font-size: 14px; color: #555; }
  </style>
</head>
<body>
  <!-- Background Slider -->
  <div class="background-slider">
    <img src="https://images.unsplash.com/photo-1506744038136-46273834b3fb" alt="">
    <img src="https://images.unsplash.com/photo-1523810986600-9f1d4aa6e0c4" alt="">
    <img src="https://images.unsplash.com/photo-1508780709619-79562169bc64" alt="">
  </div>
  <div class="overlay"></div>

  <!-- Header -->
  <header>
    <div>
      <h1>ClearFunds</h1>
      <p>See Where Your Money Goes</p>
    </div>
    <button class="transactions-btn" onclick="window.location.href='ViewMyTransactions.php'">View My Transactions</button>
  </header>

  <!-- Search -->
  <div class="search-container">
    <input type="text" class="search-bar" placeholder="Search NGOs by Name or Cause" onkeyup="searchNGOs()">
  </div>

  <!-- NGO List -->
  <div class="ngo-list" id="ngoList">
    <div class="ngo-card">
      <h3>Helping Hands</h3>
      <p>Providing education to underprivileged children.</p>
      <button class="view-btn" onclick="openModal('Helping Hands','Helping Hands focuses on providing quality education and resources to children in need.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Green Earth</h3>
      <p>Working towards a cleaner and greener planet.</p>
      <button class="view-btn" onclick="openModal('Green Earth','Green Earth works on afforestation projects and environmental awareness campaigns.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Health First</h3>
      <p>Medical aid and wellness for everyone.</p>
      <button class="view-btn" onclick="openModal('Health First','Health First provides free medical camps and wellness programs.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Food For All</h3>
      <p>Delivering meals to those in need every day.</p>
      <button class="view-btn" onclick="openModal('Food For All','Food For All ensures nutritious meals reach underprivileged families and homeless individuals.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Clean Water Initiative</h3>
      <p>Providing clean drinking water to rural areas.</p>
      <button class="view-btn" onclick="openModal('Clean Water Initiative','This NGO sets up water filtration and supply systems for villages.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Animal Care</h3>
      <p>Rescuing and sheltering stray animals.</p>
      <button class="view-btn" onclick="openModal('Animal Care','Animal Care provides rescue operations and permanent shelter for strays.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Women Empowerment Group</h3>
      <p>Empowering women through education and skill development.</p>
      <button class="view-btn" onclick="openModal('Women Empowerment Group','This group offers free courses and funding opportunities for women.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Tree Savers</h3>
      <p>Promoting afforestation and reducing deforestation.</p>
      <button class="view-btn" onclick="openModal('Tree Savers','Tree Savers plants trees and educates communities about the environment.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Disaster Relief Team</h3>
      <p>Providing quick aid during natural disasters.</p>
      <button class="view-btn" onclick="openModal('Disaster Relief Team','Disaster Relief Team delivers essential supplies during emergencies.')">View Details</button>
    </div>
    <div class="ngo-card">
      <h3>Tech For Good</h3>
      <p>Using technology to solve social problems.</p>
      <button class="view-btn" onclick="openModal('Tech For Good','Tech For Good builds innovative tech solutions to improve communities.')">View Details</button>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal" id="ngoModal">
    <div class="modal-content">
      <span class="close-btn" onclick="closeModal()">&times;</span>
      <h3 id="ngoTitle"></h3>
      <p id="ngoDescription"></p>
      <button class="donate-btn" id="donateBtn">Donate Now</button>
    </div>
  </div>

  <!-- Footer -->
  <footer>&copy; 2025 ClearFunds | Made with ❤️ by Team IMPROVECTS</footer>

  <script>
    function openModal(title, description) {
      document.getElementById('ngoTitle').innerText = title;
      document.getElementById('ngoDescription').innerText = description;
      document.getElementById('ngoModal').style.display = 'flex';

      // Update Donate button link dynamically
      document.getElementById('donateBtn').onclick = function() {
        window.location.href = "payment.php?ngo=" + encodeURIComponent(title);
      }
    }
    function closeModal() { document.getElementById('ngoModal').style.display = 'none'; }
    function searchNGOs() {
      let input = document.querySelector('.search-bar').value.toLowerCase();
      let cards = document.querySelectorAll('.ngo-card');
      cards.forEach(card => {
        let text = card.innerText.toLowerCase();
        card.style.display = text.includes(input) ? 'block' : 'none';
      });
    }
  </script>
</body>
</html>
