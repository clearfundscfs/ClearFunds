<?php
session_start();
include 'db.php';

if (!isset($_SESSION['donor_id'])) {
    header("Location: donor_login.php");
    exit();
}
$user_id = (int) $_SESSION['donor_id'];

$sql = "SELECT t.id, n.ngo_name, t.amount, t.payment_method, t.status, t.date AS transaction_date,
               t.donor_name, t.donor_email, t.donor_mobile
        FROM transactions t
        JOIN ngos n ON t.ngo_id = n.id
        WHERE t.user_id = ?
        ORDER BY t.date DESC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Donations</title>
  <style>
    body { font-family:Arial,Helvetica,sans-serif; background:#f4f7f8; padding:20px; }
    .wrap { max-width:1100px; margin:20px auto; background:#fff; padding:18px; border-radius:10px; box-shadow:0 6px 18px rgba(0,0,0,0.06); }
    table { width:100%; border-collapse:collapse; }
    th, td { padding:10px; border-bottom:1px solid #eee; text-align:center; }
    th { background:#00bcd4; color:#fff; text-transform:uppercase; font-size:12px; }
    tr:nth-child(even) { background:#fbfcfd; }
    .status-success { color:green; font-weight:700; }
    .status-pending { color:orange; font-weight:700; }
    .status-failed { color:red; font-weight:700; }
    .back { display:block; text-align:center; margin-top:14px; }
  </style>
</head>
<body>
  <div class="wrap">
    <h2>My Donation History</h2>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>NGO</th>
          <th>Amount (₹)</th>
          <th>Payment Method</th>
          <th>Status</th>
          <th>Date</th>
          <th>Donor Name</th>
          <th>Email</th>
          <th>Mobile</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows === 0): ?>
          <tr><td colspan="9">No donations found yet.</td></tr>
        <?php else: ?>
          <?php while ($r = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo (int)$r['id']; ?></td>
              <td><?php echo htmlspecialchars($r['ngo_name']); ?></td>
              <td>₹<?php echo number_format($r['amount'], 2); ?></td>
              <td><?php echo htmlspecialchars($r['payment_method'] ?? '-'); ?></td>
              <td class="status-<?php echo strtolower($r['status']); ?>"><?php echo htmlspecialchars(ucfirst($r['status'])); ?></td>
              <td><?php echo htmlspecialchars($r['transaction_date']); ?></td>
              <td><?php echo htmlspecialchars($r['donor_name']); ?></td>
              <td><?php echo htmlspecialchars($r['donor_email']); ?></td>
              <td><?php echo htmlspecialchars($r['donor_mobile']); ?></td>
            </tr>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>

    <a class="back" href="UserInterface.php">← Back to Dashboard</a>
  </div>
</body>
</html>
