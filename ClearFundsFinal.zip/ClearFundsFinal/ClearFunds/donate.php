<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo "⚠ Please login first! <a href='login.php'>Login</a>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $ngo = $_POST['ngo'];
    $amount = $_POST['amount'];
    $status = "Successful";

    $stmt = $conn->prepare("INSERT INTO transactions (user_id, ngo, amount, status) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isds", $user_id, $ngo, $amount, $status);

    if ($stmt->execute()) {
        $msg = "Donation successful!";
    } else {
        $msg = "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Donate</title>
  <style>
    body { background:#f4f4f4; font-family:sans-serif; }
    .donate-box { width:350px; margin:100px auto; padding:30px; background:white; border-radius:10px; box-shadow:0 0 8px rgba(0,0,0,0.1); }
    input { width:100%; margin:10px 0; padding:10px; border:1px solid #ccc; border-radius:5px; }
    button { width:100%; padding:10px; background:#28a745; color:white; border:none; border-radius:5px; cursor:pointer; }
    button:hover { background:#218838; }
    .msg { margin:10px 0; color:green; }
  </style>
</head>
<body>
  <div class="donate-box">
    <h2>Donate</h2>
    <?php if(isset($msg)) echo "<p class='msg'>$msg</p>"; ?>
    <form method="POST">
      <input type="text" name="ngo" placeholder="NGO Name" required>
      <input type="number" name="amount" placeholder="Amount" required>
      <button type="submit">Donate</button>
    </form>
  </div>
</body>
</html>
