<?php
// Start session
session_start();

// Connect to database
$conn = new mysqli("localhost", "root", "", "ngo_donation");

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Get logged-in user
$user_id = $_SESSION['donor_id'] ?? 0;

// Handle file uploads
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES)) {
    $transaction_id = $_POST['transaction_id'] ?? 0;
    $upload_type = $_POST['upload_type'] ?? '';
    
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name'];
        $file_size = $_FILES['file']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Allowed file extensions
        $allowed_ext = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
        
        if (in_array($file_ext, $allowed_ext) && $file_size < 5000000) { // 5MB limit
            $upload_dir = 'uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $new_filename = uniqid() . '_' . $upload_type . '.' . $file_ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // Update database with file path - Fixed the dynamic column issue
                if ($upload_type == 'beneficiary') {
                    $sql_update = "UPDATE transactions SET beneficiary_file = ? WHERE id = ? AND user_id = ?";
                } else {
                    $sql_update = "UPDATE transactions SET receipt_file = ? WHERE id = ? AND user_id = ?";
                }
                
                $stmt_update = $conn->prepare($sql_update);
                if ($stmt_update) {
                    $stmt_update->bind_param("sii", $upload_path, $transaction_id, $user_id);
                    if ($stmt_update->execute()) {
                        echo "<script>alert('File uploaded successfully!');</script>";
                    } else {
                        echo "<script>alert('Failed to update database!');</script>";
                    }
                    $stmt_update->close();
                } else {
                    echo "<script>alert('Database error: " . $conn->error . "');</script>";
                }
            }
        } else {
            echo "<script>alert('Invalid file type or size too large!');</script>";
        }
    }
}

// Fetch transactions with NGO name - Check if columns exist first
$sql = "SELECT t.id, t.amount, t.date, t.status, n.ngo_name
        FROM transactions t
        JOIN ngos n ON t.ngo_id = n.id
        WHERE t.user_id = ?
        ORDER BY t.date DESC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NGO Transactions</title>
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    /* Full screen layout */
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      background: #e6f7f9;
      color: #333;
    }

    /* Header Section */
    header {
      background: #00bcd4;
      color: white;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 10px 20px;
    }

    /* Top Row: ClearFunds */
    .header-top {
      width: 100%;
      display: flex;
      justify-content: flex-start;
    }

    .brand {
      font-size: 22px;
      font-weight: bold;
      color: white;
      letter-spacing: 1px;
    }

    /* NGO Title Centered Below */
    .ngo-title {
      font-size: 20px;
      font-weight: bold;
      color: white;
      margin-top: 5px;
      text-align: center;
    }

    /* Main container */
    .container {
      flex: 1;
      width: 90%;
      max-width: 1000px;
      margin: 20px auto;
      background: white;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      border: 2px solid #b2ebf2;
    }

    /* Section title */
    .transactions-title {
      font-size: 1.6rem;
      font-weight: bold;
      color: #007c7c;
      margin-bottom: 20px;
      text-align: center;
    }

    /* Transaction List */
    .transaction-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f9fdfd;
      padding: 15px 20px;
      margin-bottom: 15px;
      border: 1px solid #b2ebf2;
      border-radius: 10px;
      transition: 0.3s ease;
    }

    .transaction-box:hover {
      background: #e0f7fa;
      transform: scale(1.01);
    }

    /* Transaction Info */
    .transaction-info {
      display: flex;
      flex-direction: column;
    }

    .transaction-info span {
      font-size: 1rem;
      margin-bottom: 5px;
      color: #004d4d;
    }

    /* Status styles */
    .status {
      font-weight: bold;
      padding: 5px 10px;
      border-radius: 8px;
      font-size: 14px;
      display: inline-block;
      margin-top: 5px;
    }
    
    .status.success { background: #DFF2BF; color: #4CAF50; }
    .status.pending { background: #FFF4E5; color: #FFC107; }
    .status.failed { background: #FFD2D2; color: #F44336; }

    /* Upload buttons */
    .upload-section {
      display: flex;
      gap: 10px;
      flex-direction: column;
    }

    .upload-form {
      display: flex;
      gap: 10px;
      align-items: center;
    }

    .upload-btn {
      background-color: #b2ebf2;
      color: #004d4d;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      border: 1px solid #009999;
      font-size: 0.9rem;
      transition: 0.3s ease;
      text-align: center;
    }

    .upload-btn:hover {
      background-color: #80deea;
    }

    .file-input {
      display: none;
    }

    .submit-btn {
      background-color: #00bcd4;
      color: white;
      padding: 6px 12px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.8rem;
      transition: 0.3s ease;
    }

    .submit-btn:hover {
      background-color: #0097a7;
    }

    .uploaded-file {
      color: #4CAF50;
      font-size: 0.8rem;
      margin-top: 5px;
    }

    /* Footer */
    footer {
      text-align: center;
      padding: 15px;
      background: #fff;
      border-top: 1px solid #ddd;
      font-size: 14px;
      color: #555;
    }

    footer span {
      color: #00bcd4;
      font-weight: bold;
    }

    .no-transactions {
      text-align: center;
      color: #666;
      font-size: 1.2rem;
      margin: 50px 0;
    }
  </style>
  <script>
    function showFileName(input, type, transactionId) {
      const fileName = input.files[0] ? input.files[0].name : '';
      const displayElement = document.getElementById(type + '_name_' + transactionId);
      if (displayElement) {
        displayElement.textContent = fileName ? 'Selected: ' + fileName : '';
      }
    }
  </script>
</head>
<body>
  <!-- Header -->
  <header>
    <!-- Top: ClearFunds name -->
    <div class="header-top">
      <div class="brand">ClearFunds</div>
    </div>
    <!-- Bottom: NGO Name centered -->
    <div class="ngo-title">My Transactions</div>
  </header>

  <!-- Main Container -->
  <div class="container">
    <div class="transactions-title">Money Donated Transactions</div>

    <?php if ($result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="transaction-box">
          <div class="transaction-info">
            <span><strong>NGO:</strong> <?php echo htmlspecialchars($row['ngo_name']); ?></span>
            <span><strong>Amount:</strong> ₹<?php echo number_format($row['amount'], 2); ?></span>
            <span><strong>Date:</strong> <?php echo date("d M Y", strtotime($row['date'])); ?></span>
            <span class="status <?php echo strtolower($row['status']); ?>">
              <?php echo ucfirst($row['status']); ?>
            </span>
          </div>
          
          <div class="upload-section">
            <!-- Beneficiary Upload -->
            <form method="POST" enctype="multipart/form-data" class="upload-form">
              <input type="hidden" name="transaction_id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="upload_type" value="beneficiary">
              <label class="upload-btn">
                Upload Beneficiary
                <input type="file" name="file" class="file-input" 
                       onchange="showFileName(this, 'beneficiary', <?php echo $row['id']; ?>)" 
                       accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
              </label>
              <button type="submit" class="submit-btn">Submit</button>
            </form>
            <div id="beneficiary_name_<?php echo $row['id']; ?>" class="uploaded-file"></div>

            <!-- Receipt Upload -->
            <form method="POST" enctype="multipart/form-data" class="upload-form">
              <input type="hidden" name="transaction_id" value="<?php echo $row['id']; ?>">
              <input type="hidden" name="upload_type" value="receipt">
              <label class="upload-btn">
                Upload Receipt
                <input type="file" name="file" class="file-input" 
                       onchange="showFileName(this, 'receipt', <?php echo $row['id']; ?>)" 
                       accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
              </label>
              <button type="submit" class="submit-btn">Submit</button>
            </form>
            <div id="receipt_name_<?php echo $row['id']; ?>" class="uploaded-file"></div>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <div class="no-transactions">
        <p>No transactions found.</p>
      </div>
    <?php endif; ?>
  </div>

  <!-- Footer -->
  <footer>
    &copy; 2025 <span>ClearFunds</span> | Made with ❤️ by Team IMPROVECTS
  </footer>
</body>
</html>
<?php 
$stmt->close();
$conn->close(); 
?>
