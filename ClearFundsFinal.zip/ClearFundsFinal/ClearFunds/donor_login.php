<?php
session_start();
include 'db.php';  // use the central db connection file

$error = "";

// Handle donor login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $pass = trim($_POST['password']);

    // Fetch donor by email
    $sql = "SELECT * FROM donors WHERE email=?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $donor = $result->fetch_assoc();

            // ✅ Verify hashed password
            if (password_verify($pass, $donor['password'])) {
                // Store donor details in session
                $_SESSION['donor_id']   = $donor['id'];
                $_SESSION['donor_email'] = $donor['email'];
                $_SESSION['donor_name']  = $donor['name'];  // make sure "name" exists in donors table

                header("Location: UserInterface.php"); // redirect after login
                exit();
            } else {
                $error = "❌ Invalid password!";
            }
        } else {
            $error = "❌ Donor not found with this email!";
        }

        $stmt->close();
    } else {
        $error = "Database error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donor Login</title>
  <style>
    body {
      background-color: #8efe9b;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      font-family: Arial, sans-serif;
    }
    .card {
      background: #fff;
      padding: 2rem;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      width: 100%;
      max-width: 400px;
    }
    .card h1 {
      text-align: center;
      font-size: 1.8rem;
      color: #1f2937;
      margin-bottom: 1.5rem;
    }
    form { display: flex; flex-direction: column; gap: 1rem; }
    label { font-size: 0.9rem; color: #4b5563; }
    input {
      padding: 0.7rem; border: 1px solid #ccc; border-radius: 10px;
    }
    button {
      background: #2563eb; color: white; padding: 0.8rem; border: none;
      border-radius: 12px; font-size: 1rem; cursor: pointer;
    }
    button:hover { background: #1e40af; }
    .error { color: red; text-align: center; margin-bottom: 10px; }
    .footer-text { text-align: center; margin-top: 1rem; font-size: 0.9rem; }
    .footer-text a { color: #2563eb; text-decoration: none; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Donor Login</h1>

    <?php if (!empty($error)): ?>
      <p class="error"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
      <div>
        <label for="email">Email</label>
        <input type="email" name="email" placeholder="Enter your email" required>
      </div>
      <div>
        <label for="password">Password</label>
        <input type="password" name="password" placeholder="Enter your password" required>
      </div>
      <button type="submit">Log In</button>
    </form>

    <p class="footer-text">
      New donor? <a href="donor_register.php">Register here</a>
    </p>
  </div>
</body>
</html>
