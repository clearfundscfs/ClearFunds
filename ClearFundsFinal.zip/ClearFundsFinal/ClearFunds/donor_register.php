<?php
session_start();
include 'db.php';

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // hashed password

    // Check if email already exists
    $check = $conn->prepare("SELECT id FROM donors WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $msg = "⚠️ This email is already registered. <a href='donor_login.php'>Login here</a>";
    } else {
        // Insert new donor
        $stmt = $conn->prepare("INSERT INTO donors (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            $msg = "✅ Registration successful! <a href='donor_login.php'>Login here</a>";
        } else {
            $msg = "❌ Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Donor Registration</title>
  <style>
    body { background:#f4f4f4; font-family:sans-serif; }
    .reg-box {
      width:350px; margin:100px auto; padding:30px;
      background:white; border-radius:10px; box-shadow:0 0 8px rgba(0,0,0,0.1);
    }
    input {
      width:100%; margin:10px 0; padding:10px;
      border:1px solid #ccc; border-radius:5px;
    }
    button {
      width:100%; padding:10px; background:#28a745;
      color:white; border:none; border-radius:5px; cursor:pointer;
    }
    button:hover { background:#218838; }
    .msg { margin:10px 0; font-weight:bold; text-align:center; }
  </style>
</head>
<body>
  <div class="reg-box">
    <h2>Donor Registration</h2>
    <?php if(!empty($msg)) echo "<p class='msg'>$msg</p>"; ?>
    <form method="POST">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Register</button>
    </form>
    <p style="text-align:center; margin-top:10px;">
      Already have an account? <a href="donor_login.php">Login</a>
    </p>
  </div>
</body>
</html>
