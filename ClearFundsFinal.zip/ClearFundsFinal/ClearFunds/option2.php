<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NGO Donation Page</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      color: #333;
    }

    /* Background Slider */
    .background-slider {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -2;
      overflow: hidden;
    }

    .background-slider img {
      position: absolute;
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0;
      animation: fade 15s infinite;
    }

    .background-slider img:nth-child(1) { animation-delay: 0s; }
    .background-slider img:nth-child(2) { animation-delay: 5s; }
    .background-slider img:nth-child(3) { animation-delay: 10s; }

    @keyframes fade {
      0%, 100% { opacity: 0; }
      10%, 30% { opacity: 1; }
      40% { opacity: 0; }
    }

    /* Overlay */
    .overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0.6);
      z-index: -1;
    }

    /* Hero Section */
    .hero {
      height: 70vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      color: #333;
      padding: 20px;
    }

    .hero h1 {
      font-size: 48px;
      margin-bottom: 15px;
      text-shadow: 2px 2px 6px rgba(0,0,0,0.5);
      color: #00bcd4;
    }

    .hero p {
      font-size: 20px;
      margin-bottom: 25px;
    }

    .hero button {
      padding: 15px 40px;
      font-size: 18px;
      background: #2563eb;
      border: none;
      color: white;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .hero button:hover {
      background: #1e40af;
    }

    /* Donation Cards */
    .donation-section {
      padding: 50px 20px;
      text-align: center;
    }

    .donation-section h2 {
      font-size: 32px;
      margin-bottom: 30px;
    }

    .cards {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 20px;
    }

    .card {
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
      width: 250px;
      text-align: center;
      border: 2px solid #ddd;
      transition: transform 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
      border-color: #2563eb;
    }

    .card h3 {
      font-size: 22px;
      margin-bottom: 10px;
    }

    .card p {
      font-size: 14px;
      margin-bottom: 15px;
    }

    .card button {
      padding: 10px 20px;
      background: #2563eb;
      border: none;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .card button:hover {
      background: #1e40af;
    }

    /* Progress Bar */
    .progress-container {
      margin: 50px auto;
      width: 80%;
      max-width: 600px;
      text-align: center;
    }

    .progress-bar {
      background: #ddd;
      border-radius: 20px;
      overflow: hidden;
      height: 25px;
    }

    .progress {
      background: #22c55e;
      height: 100%;
      width: 70%; /* Example progress */
      text-align: center;
      color: white;
      line-height: 25px;
      font-size: 14px;
    }

    /* Donation Form */
    .form-section {
      padding: 40px 20px;
      text-align: center;
    }

    .form-section h2 {
      margin-bottom: 20px;
      font-size: 28px;
    }

    form {
      max-width: 400px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
      text-align: left;
    }

    form label {
      font-size: 14px;
      display: block;
      margin-bottom: 6px;
      margin-top: 10px;
    }

    form input, form select {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      margin-bottom: 15px;
      font-size: 14px;
    }

    form button {
      width: 100%;
      padding: 14px;
      background: #2563eb;
      color: white;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s;
    }

    form button:hover {
      background: #1e40af;
    }

    /* Footer */
    footer {
      background: #222;
      color: white;
      padding: 20px;
      text-align: center;
      margin-top: 40px;
    }

    footer a {
      color: #90ee90;
      text-decoration: none;
      margin: 0 10px;
    }

    footer a:hover {
      text-decoration: underline;
    }

    .buttons {
      display: flex;
      justify-content: center;
      gap: 20px;
    }

    button {
      padding: 12px 24px;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-size: 1rem;
      font-weight: bold;
      color: white;
      transition: 0.3s;
    }

    button:first-child {
      background-color:  #16a34a; /* green */
    }
    button:first-child:hover {
      background-color: #1d4ed8;
    }

    button:last-child {
      background-color:#2563eb; /* blue */
    }
    button:last-child:hover {
      background-color: #15803d;
    }
  </style>
</head>
<body>
  <!-- Background Slider -->
  <div class="background-slider">
    <img src="https://images.unsplash.com/photo-1509099836639-18ba1795216d" alt="Helping Hands">
    <img src="https://images.unsplash.com/photo-1465146633011-14f18f0bf4a0" alt="Tree Plantation">
    <img src="https://images.unsplash.com/photo-1509099836639-18ba1795216d" alt="Food Donation">
  </div>
  <div class="overlay"></div>
  
  <!-- Hero Section -->
  <section class="hero">
    <h1>ClearFunds</h1>
    <p>See where your money goes</p>
  </section>

  <!-- Donation Cards -->
  <section class="donation-section">
    <h2>Choose your role</h2>
    <div class="buttons">
      <a href="login.php">
        <button class="btn1">DONOR</button>
      </a>
      <a href="login1.php">
        <button class="btn1">NGO</button>
      </a>
      <a href="login2.php">
        <button class="btn1">TRUST</button>
      </a>
    </div>
    <p id="message"></p>
  </section>

  <!-- Progress Bar -->
  <section class="progress-container">
    <h2>Donation Goal</h2>
    <div class="progress-bar">
      <div class="progress">70% Reached</div>
    </div>
    <p>₹70,000 raised of ₹1,00,000 goal</p>
  </section>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 NGO Foundation | 
      <a href="about_page.php">About Us</a> | 
      <a href="contact.php">Contact</a> | 
      <a href="#">Transparency Report</a>
    </p>
  </footer>
</body>
</html>
