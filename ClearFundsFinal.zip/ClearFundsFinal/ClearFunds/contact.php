<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Contact Us</title>
  <style>
    body { font-family:Arial; background:#f4f4f4; }
    .container { width:60%; margin:50px auto; background:white; padding:30px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.1); }
    h1 { color:#2c3e50; }
    p { font-size:16px; margin:10px 0; }
    a { display:inline-block; margin-top:20px; padding:10px 20px; background:#007bff; color:white; border-radius:5px; text-decoration:none; }
    a:hover { background:#0056b3; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Contact Us</h1>
    <p>📧 Email: support@clearfunds.org</p>
    <p>📞 Phone: +91 98765 43210</p>
    <p>🏢 Address: Ahmedabad, India</p>
    <a href="option2.php">⬅ Back</a>
  </div>
</body>
</html>
