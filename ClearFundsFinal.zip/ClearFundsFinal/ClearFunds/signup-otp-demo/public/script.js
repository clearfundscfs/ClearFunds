async function sendOtp() {
  const email = document.getElementById("email").value;
  const msg = document.getElementById("email-msg");

  if (!email) {
    msg.innerText = "Please enter your Gmail!";
    return;
  }

  msg.innerText = "Sending OTP...";
  try {
    const res = await fetch("/send-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    if (data.success) {
      msg.style.color = "green";
      msg.innerText = "OTP sent to your Gmail!";
      document.getElementById("otp-section").style.display = "block";
    } else {
      msg.style.color = "red";
      msg.innerText = data.message || "Failed to send OTP.";
    }
  } catch (err) {
    msg.style.color = "red";
    msg.innerText = "Error sending OTP.";
  }
}

async function verifyOtp() {
  const email = document.getElementById("email").value;
  const otp = document.getElementById("otp").value;
  const msg = document.getElementById("otp-msg");

  if (!otp) {
    msg.innerText = "Please enter the OTP!";
    return;
  }

  msg.innerText = "Verifying...";
  try {
    const res = await fetch("/verify-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, otp }),
    });
    const data = await res.json();
    if (data.success) {
      msg.style.color = "green";
      msg.innerText = "OTP verified! Signup successful.";
    } else {
      msg.style.color = "red";
      msg.innerText = data.message || "Invalid OTP.";
    }
  } catch (err) {
    msg.style.color = "red";
    msg.innerText = "Error verifying OTP.";
  }
}
