const express = require("express");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// Debugging middleware (to see every request)
app.use((req, res, next) => {
    console.log("Request received:", req.method, req.url);
    next();
});

// Middleware
app.use(express.static("public")); // serve files from /public
app.use(bodyParser.json());

// In-memory store for OTPs
let otps = {};

// API: Send OTP
app.post("/send-otp", async(req, res) => {
    const { email } = req.body;
    console.log("Send OTP request for:", email);

    if (!email) {
        return res.status(400).json({ success: false, message: "Email required" });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000);
    otps[email] = otp;

    try {
        let transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.GMAIL_USER,
                pass: process.env.GMAIL_PASS,
            },
        });

        await transporter.sendMail({
            from: `"OTP Service" <${process.env.GMAIL_USER}>`,
            to: email,
            subject: "Your OTP Code",
            text: `Your OTP is ${otp}`,
        });

        console.log(`✅ OTP sent to ${email}: ${otp}`);
        res.json({ success: true, message: "OTP sent successfully" });
    } catch (error) {
        console.error("❌ Error sending OTP:", error);
        res.status(500).json({ success: false, message: "Error sending OTP" });
    }
});

// API: Verify OTP
app.post("/verify-otp", (req, res) => {
    const { email, otp } = req.body;
    console.log("Verify OTP request for:", email, "with OTP:", otp);

    if (otps[email] && otps[email] == otp) {
        delete otps[email]; // remove OTP after successful verification
        console.log("✅ OTP verified successfully for:", email);
        return res.json({ success: true, message: "OTP verified successfully" });
    }

    console.log("❌ OTP verification failed for:", email);
    res.status(400).json({ success: false, message: "Invalid OTP" });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
    console.log("GMAIL_USER:", process.env.GMAIL_USER);
    console.log("GMAIL_PASS loaded?", !!process.env.GMAIL_PASS);
});